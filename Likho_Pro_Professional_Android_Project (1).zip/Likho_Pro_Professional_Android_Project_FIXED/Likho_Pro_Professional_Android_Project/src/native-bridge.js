import { registerPlugin } from '@capacitor/core';

const NativeFiles = registerPlugin('NativeFiles');
window.LikhoNativeFiles = NativeFiles;

function bytesToBase64(bytes) {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}
async function fileToBase64(file) {
  return bytesToBase64(new Uint8Array(await file.arrayBuffer()));
}
async function importUri(uri, name, mimeType) {
  const result = await NativeFiles.readFile({ uri });
  const raw = atob(result.base64);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
  const file = new File([bytes], name || result.name || 'Imported file', {
    type: mimeType || result.mimeType || 'application/octet-stream'
  });
  if (window.LikhoProImportFiles) return window.LikhoProImportFiles(file);
  throw new Error('Likho Pro importer is not ready');
}
window.LikhoProNativePickFile = async function () {
  try {
    const picked = await NativeFiles.pickFile({});
    await importUri(picked.uri, picked.name, picked.mimeType);
  } catch (e) {
    if (e && e.message !== 'User cancelled') console.warn('File picker:', e);
  }
};
window.LikhoProNativeSave = async function (blob, name) {
  try {
    const file = new File([blob], name || 'Likho-Pro-Export', { type: blob.type || 'application/octet-stream' });
    await NativeFiles.saveFile({
      name: file.name,
      mimeType: file.type,
      base64: await fileToBase64(file)
    });
  } catch (e) {
    console.error('Save As failed:', e);
    alert('फाइल सेव नहीं हो सकी। कृपया दोबारा कोशिश करें।');
  }
};
window.LikhoProNativeShare = async function (file) {
  await NativeFiles.shareFile({
    name: file.name,
    mimeType: file.type || 'application/octet-stream',
    base64: await fileToBase64(file)
  });
};
async function handleIncoming(data) {
  if (!data || !data.uri) return;
  try {
    const result = await NativeFiles.readFile({ uri: data.uri });
    if (window.LikhoProOpenSharedFile) {
      await window.LikhoProOpenSharedFile(
        data.name || result.name || 'Shared file',
        data.mimeType || result.mimeType,
        result.base64
      );
    }
  } catch (e) {
    console.error('Could not open incoming file:', e);
    alert('यह फाइल Likho Pro में नहीं खुल सकी। फाइल का Format समर्थित होना चाहिए।');
  }
}
NativeFiles.addListener('fileOpened', handleIncoming);
NativeFiles.getPendingOpen().then(async pending => {
  if (pending && pending.uri) await handleIncoming(pending);
}).catch(e => console.warn('Pending open:', e));

window.LikhoProOpenAndroidSettings = () => NativeFiles.openAppSettings();
window.LikhoProGetAppInfo = () => NativeFiles.getAppInfo();
